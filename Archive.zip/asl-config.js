{
    "skillId" : "amzn1.ask.skill.8dc5e094-a8ef-46b1-904c-a1112d2917a7",
    "stage" : "development"
}